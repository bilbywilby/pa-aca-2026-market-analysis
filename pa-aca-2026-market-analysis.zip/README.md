# Pennsylvania ACA 2026 Market Data
This repository contains neutral, verified data on approved 2026 ACA individual market premium changes in Pennsylvania.

## Contents
- County to Rating Area mappings
- Carrier premium change approvals
- PDF market report and executive brief
- Reproducible visuals

## Use
Journalists, researchers, and policymakers may use this data to analyze geographic and insurer-specific impacts of 2026 rate changes.
